# Mini Project Assessment: REST API using Node.js and Express.js

## 📋 Objective

This project demonstrates the creation of a simple REST API using Node.js and Express.js. It covers basic CRUD operations, error handling, and in-memory data management.

---

## 🚀 Getting Started

### Prerequisites

- Node.js (v14 or higher recommended)
- npm (Node Package Manager)

### Installation

1. Clone the repository or copy the `app.js` file into a folder.
2. Navigate to the project folder:

   ```bash
   cd mini-rest-api
   ```

3. Initialize the project and install Express:

   ```bash
   npm init -y
   npm install express
   ```

4. Start the server:

   ```bash
   node app.js
   ```

5. Open your browser or API tool and navigate to:

   ```
   http://localhost:3000
   ```

---

## 📌 API Endpoints

All endpoints accept and return JSON.

### ✅ Root

- `GET /`
  - Response: `"Hello, World!"`

---

### 📦 Items Resource

Each item includes:
```json
{
  "id": 1,
  "name": "Notebook",
  "description": "A ruled notebook."
}
```

---

#### 🔹 Get All Items

- `GET /items`
- Response: Array of all items.

#### 🔹 Get Item by ID

- `GET /items/:id`
- Params: `id` (integer)
- Response: Item object if found, 404 if not.

#### 🔹 Create New Item

- `POST /items`
- Body:
  ```json
  {
    "name": "Pen",
    "description": "A blue ink pen"
  }
  ```
- Response: Newly created item with `id`.

#### 🔹 Update Item by ID

- `PUT /items/:id`
- Params: `id` (integer)
- Body:
  ```json
  {
    "name": "Updated Name",
    "description": "Updated Description"
  }
  ```
- Response: Updated item if successful.

#### 🔹 Delete Item by ID

- `DELETE /items/:id`
- Params: `id` (integer)
- Response: Success message with deleted item.

---

## ⚠️ Error Handling

- `400 Bad Request` — If `name` or `description` is missing.
- `404 Not Found` — If item with specified ID doesn't exist.
- `500 Internal Server Error` — For unexpected server issues.

---

## 🧪 Example Requests (Postman)

### Create Item

```
POST http://localhost:3000/items
Content-Type: application/json

{
  "name": "Marker",
  "description": "A black marker"
}
```

### Response:

```json
{
  "id": 3,
  "name": "Marker",
  "description": "A black marker"
}
```

---

## ✅ Assessment Requirements Covered

- Express.js application setup with middleware ✅  
- CRUD operations with validation ✅  
- In-memory data store ✅  
- Error handling with clear messages ✅  
- Example API requests and setup guide ✅  

---

## 📚 License

This is a simple educational project and is open for learning and modification.
